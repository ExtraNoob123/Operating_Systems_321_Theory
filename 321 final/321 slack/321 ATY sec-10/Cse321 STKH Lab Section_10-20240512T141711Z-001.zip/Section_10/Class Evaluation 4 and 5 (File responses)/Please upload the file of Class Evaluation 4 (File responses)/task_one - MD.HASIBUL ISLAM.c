#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    FILE *fp;
    pid_t pid1, pid2;

    
    fp = fopen("data.txt", "w");
    if (fp == NULL) {
        printf("Error creating file\n");
        return 1;
    }

   
    pid1 = fork();

   
    if (pid1 == 0) {
     
        fprintf(fp, "Hello I am child One\n");
        exit(0);
    }

   
    pid2 = fork();

    if (pid2 == 0) {
   
        fprintf(fp, "Child two has been created\n");
        exit(0);
    }

   
    wait(NULL);
    wait(NULL);

    fclose(fp); 
    
    fp = fopen("data.txt", "r");
    

   
    char string[100];
    
    while (fgets(string, sizeof(string), fp) != NULL) {
        printf("%s", string);
    }

    fclose(fp);

    return 0;

}

