#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main() {
    
    int fd = open("data.txt",O_WRONLY);
    

   
    pid_t child1 = fork();
   
    if (child1 == 0) { 
    	
    	static char msg[]="Hello I am child One\n";
        
        write(fd, msg, strlen(msg));
        close(fd);
        exit(EXIT_SUCCESS);
    }
    else{
    wait();
    }

  
    pid_t child2 = fork();
    
    if (child2 == 0) { 
        
    	static char msg[]="Child Two has been created\n";
    	 write(fd, msg, strlen(msg));
        close(fd);
        exit(EXIT_SUCCESS);
    }
    else{
    wait();
    }

    // Parent process
    close(fd);

   

    // Read and print the contents of "data.txt"
    char ans[300];
    fd = open("data.txt", O_RDONLY);
    
    
    read(fd, ans, sizeof(ans))
        
    printf("%s",ans);
    close(fd);
    

    return 0;
}

