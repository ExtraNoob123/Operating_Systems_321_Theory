#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main() {
    FILE *fp;
    pid_t pid1;
    pid_t pid2;
    fp = fopen("data.txt", "w");

    //c1 
    pid1 = fork();
    if (pid1 < 0) {
        printf("Failed \n");
        return 1;
    } else if (pid1 == 0) {
        //c1 write
        fprintf(fp, "Hello I am child One\n");
        fclose(fp);
        exit(0);
    }

    //c2
    pid2 = fork();
    if (pid2 < 0) {
        printf("Failed \n");
        return 1;
    } 
    else if (pid2 == 0) {
	//c2 write
        fp = fopen("data.txt", "a");
        fprintf(fp, "Child two has been created\n");
        fclose(fp);
        exit(0);
    }
    sleep(2); 

    fp = fopen("data.txt", "r");
    char buffer[100];
    while (fgets(buffer,sizeof(buffer),fp))
    {
        printf("%s",buffer);
    }
    fclose(fp);
    return 0;
}

