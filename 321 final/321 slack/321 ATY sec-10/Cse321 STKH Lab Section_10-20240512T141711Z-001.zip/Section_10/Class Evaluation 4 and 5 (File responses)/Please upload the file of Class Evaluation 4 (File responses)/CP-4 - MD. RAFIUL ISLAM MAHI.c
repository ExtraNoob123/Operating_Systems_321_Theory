#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    int fd = open("data.txt", O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (fd == -1) {
        perror("Failed to create file");
        return 1;
    }
   
    pid_t pid1 = fork();
    if (pid1 == -1) {
        perror("Failed to fork first child");
        return 1;
    } else if (pid1 == 0) { 
        const char *msg1 = "Hello I am child One\n";
        if (write(fd, msg1, strlen(msg1)) == -1) {
            perror("Failed to write to file");
            return 1;
        }
        exit(0);
    }
   
    pid_t pid2 = fork();
    if (pid2 == -1) {
        perror("Failed to fork second child");
        return 1;
    } else if (pid2 == 0) { 
        const char *msg2 = "Child two has been created\n";
        if (write(fd, msg2, strlen(msg2)) == -1) {
            perror("Failed to write to file");
            return 1;
        }
        exit(0);
    }
   
    wait(NULL);
    wait(NULL);
   
    close(fd);
   
    fd = open("data.txt", O_RDONLY);
    if (fd == -1) {
        perror("Failed to open file for reading");
        return 1;
    }
   
    char buffer[256];
    ssize_t bytes_read;
    printf("Contents of data.txt:\n");
    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        write(STDOUT_FILENO, buffer, bytes_read);
    }
    if (bytes_read == -1) {
        perror("Failed to read from file");
        return 1;
    }
   
    close(fd);
   
    return 0;
}
