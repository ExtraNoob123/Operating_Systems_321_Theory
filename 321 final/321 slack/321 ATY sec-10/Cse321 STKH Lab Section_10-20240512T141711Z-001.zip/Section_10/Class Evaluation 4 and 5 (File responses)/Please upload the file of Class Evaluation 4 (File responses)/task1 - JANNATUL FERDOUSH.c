include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
 
    FILE *file = fopen("data.txt", "w");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

  
    pid_t child_pid1 = fork();

    if (child_pid1 == -1) {
        perror("Error forking child 1");
        return 1;
    } else if (child_pid1 == 0) {
        // Child 1 process
        fprintf(file, "Hello I am child One\n");
        fclose(file);
        exit(0);
    }

  
    pid_t child_pid2 = fork();

    if (child_pid2 == -1) {
        perror("Error forking child 2");
        return 1;
    } else if (child_pid2 == 0) {
    
        file = fopen("data.txt", "a");
        if (file == NULL) {
            perror("Error opening file in child 2");
            return 1;
        }
        fprintf(file, "Child two has been created\n");
        fclose(file);
        exit(0);
    }

    
    wait(NULL); // Wait for child 1 to finish
    wait(NULL); // Wait for child 2 to finish

 
    file = fopen("data.txt", "r");
    if (file == NULL) {
        perror("Error opening file for reading");
        return 1;
    }

   
    char buffer[100];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
    }

    fclose(file);

    return 0;
}
