#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>

int main() {

    FILE *file = fopen("data.txt", "w");
    if (file == NULL) {
        perror("Error creating file");
        exit(EXIT_FAILURE);
    }


    pid_t first_child = fork();

    if (first_child < 0) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    } else if (first_child == 0) {

        fprintf(file, "Hello I am child One\n");
        fclose(file);
        exit(EXIT_SUCCESS);
    } else {

        pid_t second_child = fork();

        if (second_child < 0) {
            perror("Fork failed");
            exit(EXIT_FAILURE);
        } else if (second_child == 0) {

            file = fopen("data.txt", "a");
            if (file == NULL) {
                perror("Error opening file");
                exit(EXIT_FAILURE);
            }
            fprintf(file, "Child two has been created\n");
            fclose(file);
            exit(EXIT_SUCCESS);
        } else {

            wait(NULL);
            wait(NULL);


            file = fopen("data.txt", "r");
            if (file == NULL) {
                perror("Error opening file");
                exit(EXIT_FAILURE);
            }

            char buffer[100];
            while (fgets(buffer, sizeof(buffer), file) != NULL) {
                printf("%s", buffer);
            }

            fclose(file);
        }
    }

    return 0;
}
