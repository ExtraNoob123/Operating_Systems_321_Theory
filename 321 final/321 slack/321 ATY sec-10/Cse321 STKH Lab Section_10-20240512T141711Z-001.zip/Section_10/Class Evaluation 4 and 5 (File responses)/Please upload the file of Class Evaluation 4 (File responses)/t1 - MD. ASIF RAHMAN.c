#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    char buffer[250];
   
    FILE *file = fopen("data.txt", "w");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

  
    int pid1 = fork();

    if (pid1 == -1) {
        perror("Error forking child 1");
        return 1;
    } else if (pid1 == 0) {
       
        fprintf(file, "Hello I am child One\n");
        fclose(file);
        exit(0);
    }

    
    int pid2 = fork();

    if (pid2 == -1) {
        perror("Error forking child 2");
        return 1;
    } else if (pid2 == 0) {
        
        file = fopen("data.txt", "a");
        if (file == NULL) {
            perror("Error opening file in child 2");
            return 1;
        }
        fprintf(file, "Child two has been created\n");
        fclose(file);
        exit(0);
    }
 
    wait(NULL);
    wait(NULL); 

    file = fopen("data.txt", "r");
    if (file == NULL) {
        perror("Error opening file for reading");
        return 1;
    }

    
    
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
    }

    fclose(file);

    return 0;
}
