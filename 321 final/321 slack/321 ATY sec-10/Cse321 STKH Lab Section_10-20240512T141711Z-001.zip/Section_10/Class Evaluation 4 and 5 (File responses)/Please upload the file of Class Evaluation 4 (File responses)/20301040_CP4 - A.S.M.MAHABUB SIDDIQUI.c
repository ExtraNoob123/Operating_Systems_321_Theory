#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    FILE *file;
    pid_t pid1, pid2;

    file = fopen("data.txt", "a");

    pid1 = fork();
    if (pid1 == 0) {
        fprintf(file, "Hello I am child One\n");
        fclose(file);
        return 0;
    }

    pid2 = fork();
    if (pid2 == 0) {
        fprintf(file, "Child two has been created\n");
        fclose(file);
        return 0;
    }

    wait(NULL);
    wait(NULL);

    fclose(file);
    file = fopen("data.txt", "r");

 
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
    }

    fclose(file);
    return 0;
}

