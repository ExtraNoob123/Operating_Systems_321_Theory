#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    int fd;
    pid_t child1, child2;

    fd = open("data.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) {
        perror("open");
        exit(Exit_failed);
    }

    child1 = fork();
    if (child1 == 0) {
        dprintf(fd, "Hello I am child One\n");
        close(fd);
        exit(Ecit_success);
    }
    child2 = fork();
    if (child2 == 0) {
        dprintf(fd, "Child two has been created\n");
        close(fd);
        exit(Exit_success);
    }

    wait(NULL);
    wait(NULL);
    close(fd);

    fd = open("data.txt", O_RDONLY);
    if (fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }
    char buffer[50];
    ssize_t bytes_read;
    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        write(STDOUT_FILENO, buffer, bytes_read);
    }
    close(fd);
    return 0;
}
