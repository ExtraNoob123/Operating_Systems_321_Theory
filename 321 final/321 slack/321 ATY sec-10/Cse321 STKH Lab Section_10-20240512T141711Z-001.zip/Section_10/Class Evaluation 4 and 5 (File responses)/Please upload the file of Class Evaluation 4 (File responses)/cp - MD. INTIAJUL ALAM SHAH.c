#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<fcntl.h>
#include <string.h>
int main() {
	int fd;
	fd = open("data.txt", O_RDWR);
	if (fd == -1) {
		perror("Failed to create file;");
		return 1;
}
	pid_t pid1=fork();
	if (pid1<0) {
		perror("Fork failed");
		return 1;
}	else if (pid1 == 0){
	char *msg1 = "Hello I am child one\n";
	write(fd, msg1, strlen(msg1));
	exit(0);


}

	pid_t pid2 = fork;
	if (pid2 < 0){
		perror("Fork Failed");
		return 1;
}	else if (pid2==0){
	char *msg2 = "Child two has been created\n";
	write(fd, msg2, strlen(msg2));
exit(0);
}
wait(NULL);
wait(NULL);

close(fd);

fd = open("data.txt", O_RDONLY);
if (fd==-1){
fd = open("data.txt", O_RDONLY);
    if (fd == -1) {
        perror("Failed to open file for reading");
        return 1;
    }
    
    char buffer[100];
    ssize_t bytes_read;
    printf("Contents of data.txt:\n");
    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        write(STDOUT_FILENO, buffer, bytes_read);
    }
    
    close(fd);
    
    return 0;
}
