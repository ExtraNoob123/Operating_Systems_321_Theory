#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
int main() {
    int file_descriptor;
    pid_t pid1, pid2;
    char buffer[100];
    file_descriptor = open("data.txt", O_WRONLY | O_CREAT, 0644);
    if (file_descriptor == -1) {
        perror("Error opening file");
        return 1;
    }
    pid1 = fork();
    if (pid1 < 0) {
        perror("Fork failed");
        return 1;
    } else if (pid1 == 0) {
        const char *message1 = "Hello I am child One\n";
        write(file_descriptor, message1, strlen(message1));
        close(file_descriptor);
        return 0;
    }
    pid2 = fork();
    if (pid2 < 0) {
        perror("Fork failed");
        return 1;
    } else if (pid2 == 0) {
        const char *message2 = "Child two has been created\n";
        write(file_descriptor, message2, strlen(message2));
        close(file_descriptor);
        return 0;
    }
    wait(NULL);
    wait(NULL);
    close(file_descriptor);
    file_descriptor = open("data.txt", O_RDONLY);
    if (file_descriptor == -1) {
        perror("Error opening file");
        return 1;
    }
    ssize_t bytes_read = read(file_descriptor, buffer, sizeof(buffer));
    if (bytes_read == -1) {
        perror("Error reading from file");
        close(file_descriptor);
        return 1;
    }
    write(1, buffer, bytes_read);

    close(file_descriptor);

    return 0;
}

