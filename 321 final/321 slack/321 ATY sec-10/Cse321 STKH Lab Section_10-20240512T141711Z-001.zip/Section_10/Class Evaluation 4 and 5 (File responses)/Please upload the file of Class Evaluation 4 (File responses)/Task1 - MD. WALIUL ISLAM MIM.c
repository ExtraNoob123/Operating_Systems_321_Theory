#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    int fd = open("data.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) {
        perror("Error creating file");
        exit(EXIT_FAILURE);
    }

    pid_t child1 = fork();
    if (child1 == -1) {
        perror("Error forking child 1");
        exit(EXIT_FAILURE);
    } else if (child1 == 0) {
        char message1[] = "Hello I am child One\n";
        write(fd, message1, sizeof(message1));
        exit(EXIT_SUCCESS);
    }

    pid_t child2 = fork();
    if (child2 == -1) {
        perror("Error forking child 2");
        exit(EXIT_FAILURE);
    } else if (child2 == 0) {
        char message2[] = "Child two has been created\n";
        write(fd, message2, sizeof(message2));
        exit(EXIT_SUCCESS);
    }

    wait(NULL);
    wait(NULL);

    close(fd);

    char buffer[100];
    fd = open("data.txt", O_RDONLY);
    if (fd == -1) {
        perror("Error opening file for reading");
        exit(EXIT_FAILURE);
    }
    ssize_t bytesRead = read(fd, buffer, sizeof(buffer));
    if (bytesRead > 0) {
        printf("Contents of data.txt:\n%s", buffer);
    } else {
        printf("Error reading from file\n");
    }
    close(fd);

    return 0;
}
