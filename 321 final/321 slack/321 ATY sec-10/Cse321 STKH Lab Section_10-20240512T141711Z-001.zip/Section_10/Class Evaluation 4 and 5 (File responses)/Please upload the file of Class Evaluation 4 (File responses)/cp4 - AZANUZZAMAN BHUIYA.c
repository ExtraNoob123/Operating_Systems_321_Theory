#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main() {
    FILE *fpoint = fopen("data.txt", "w");
    if (fpoint == NULL) {
        perror("fopen failed");
        exit(1);
    }

    pid_t pid1 = fork();
    if (pid1 == 0) {
        fprintf(fpoint, "Hello I am child One\n");
        fclose(fpoint);
        exit(0);
        
     return 0;
    }
