#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

int main() {
    pid_t pid1, pid2;
    int fd;
    char *msg1 = "Hello I am child One\n";
    char *msg2 = "Child two has been created\n";

    
    fd = open("data.txt", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
    if (fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    
    pid1 = fork();
    if (pid1 == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid1 == 0) {
        
        if (write(fd, msg1, strlen(msg1)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }
        exit(EXIT_SUCCESS);
    }

    
    pid2 = fork();
    if (pid2 == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid2 == 0) {
        
        if (write(fd, msg2, strlen(msg2)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }
        exit(EXIT_SUCCESS);
    }

    
    wait(NULL);
    wait(NULL);

    
    if (close(fd) == -1) {
        perror("close");
        exit(EXIT_FAILURE);
    }

    
    fd = open("data.txt", O_RDONLY);
    if (fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    
    char ch;
    printf("Contents of data.txt:\n");
    while (read(fd, &ch, 1) > 0) {
        putchar(ch);
    }

    
    if (close(fd) == -1) {
        perror("close");
        exit(EXIT_FAILURE);
    }

    return 0;
}

