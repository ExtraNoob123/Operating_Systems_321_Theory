#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>

int main() {
    int fd;
    pid_t pid1, pid2;

    fd = open("data.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        perror("Failed to open file");
        return 1;
    }

    pid1 = fork();
    if (pid1 == 0) {
        const char *text1 = "Hello I am child One\n";
        write(fd, text1, strlen(text1));
        close(fd);
        exit(0);
    }

    pid2 = fork();
    if (pid2 == 0) {
        const char *text2 = "Child two has been created\n";
        write(fd, text2, strlen(text2));
        close(fd);
        exit(0);
    }

    close(fd);
    waitpid(pid1, NULL, 0);
    waitpid(pid2, NULL, 0);

    char buffer[1024];
    fd = open("data.txt", O_RDONLY);
    if (fd < 0) {
        perror("Failed to open file for reading");
        return 1;
    }
    
    read(fd, buffer, sizeof(buffer));
    close(fd);
    printf("Content of data.txt:\n%s\n", buffer);

    return 0;
}
