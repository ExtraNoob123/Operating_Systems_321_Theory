#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>


int main(){
    int fd = open("data.txt", O_RDWR | O_CREAT, 0666);


    pid_t a, b;
    char msg1[] = "Hello I am child One\n";
    char msg2[] = "Hello I am child One\n";
    for(int i = 0; i < 2; ++i){
        if(i == 0){
            a = fork();
            if(a == 0){
                
                write(fd, msg1, sizeof msg1);
            }else wait(NULL);
        }else{
            b = fork();
            if(b == 0){
                
                write(fd, msg2, sizeof msg2);
            }else{
                wait(NULL);
            }
        }
    }

    if(a != 0 && b!= 0){
        char buffer[100];
        read(fd, buffer, sizeof(msg1) + sizeof(msg2));
        write(0, buffer, sizeof(msg1) + sizeof(msg2));
    }
    




    return 0;
}