#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main() {
    int pid, status, fd;
    char *msg1 = "Hello I am child One\n";
    char *msg2 = "Child two has been created\n";
    char buffer[200];
    fd = open("data.txt", O_CREAT | O_RDWR, 0666);
    if (fd == -1) {
        printf("Error creating file\n");
        exit(1);
    }

    pid = fork();
    if (pid == 0) {
        write(fd, msg1, strlen(msg1));
        close(fd);
        exit(0);
    }
    pid = fork();
    if (pid == 0) {
        write(fd, msg2, strlen(msg2));
        close(fd);
        exit(0);
    }
    wait(&status);
    wait(&status);

    lseek(fd, 0, SEEK_SET);
    read(fd, buffer, sizeof(buffer));
    printf("%s\n", buffer);

    close(fd);

    return 0;
}

