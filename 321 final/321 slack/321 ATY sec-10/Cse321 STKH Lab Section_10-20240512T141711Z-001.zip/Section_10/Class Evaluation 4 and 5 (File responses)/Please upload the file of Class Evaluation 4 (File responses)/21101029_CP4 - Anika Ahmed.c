#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>

int main() {
    int fd = open("data.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    pid_t pid1 = fork();
    
    if (pid1 == 0) {
        char *line1 = "Hello I am child One\n";
        write(fd, line1, strlen(line1));
        exit(EXIT_SUCCESS);
    }
    pid_t pid2 = fork();
    
    if (pid2 == 0) {
        char *line2 = "Child two has been created\n";
        write(fd, line2, strlen(line2));
        exit(EXIT_SUCCESS);
    }
    close(fd);
    int status;
    waitpid(pid1, &status, 0);
    waitpid(pid2, &status, 0);
    fd = open("data.txt", O_RDONLY);
    
    char buffer[100];
    ssize_t s;
    printf("Contents of data.txt:\n");
    while ((s = read(fd, buffer, sizeof(buffer))) > 0) {
        write(STDOUT_FILENO, buffer, s);
    }
    printf("\n");
    close(fd);
    
    return 0;
}

