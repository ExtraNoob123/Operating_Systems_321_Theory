#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {    
    FILE *file=fopen("data.txt","w");
    if (file==NULL) {
        perror("Error for creating file");
        return 1;
    }
    pid_t pid1=fork();
    if (pid1==-1) {
        perror("Error for creating child process");
        return 1;
    } else if (pid1==0) {
        fprintf(file, "Hello I am child One\n");
        fclose(file);
        exit(0);
    }
    pid_t pid2=fork();
    if (pid2==-1) {
        perror("Error for creating child process");
        return 1;
    } else if (pid2==0) {
        fprintf(file, "Child two has been created\n");
        fclose(file);
        exit(0);
    }
    int status;
    waitpid(pid1,&status,0);
    waitpid(pid2,&status,0);
    fseek(file,0,SEEK_SET);
    char ch;
    while ((ch=fgetc(file))!=EOF) {
        printf("%c",ch);
    }
    fclose(file); 
    return 0;
}

