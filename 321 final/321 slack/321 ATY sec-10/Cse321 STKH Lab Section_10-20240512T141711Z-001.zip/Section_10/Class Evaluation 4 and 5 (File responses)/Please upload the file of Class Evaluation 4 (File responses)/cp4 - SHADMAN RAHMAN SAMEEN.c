#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    
    FILE *file_ptr;

    
    file_ptr = fopen("data.txt", "w");

    
    if (file_ptr == NULL) {
        perror("Error creating file");
        exit(EXIT_FAILURE);
    }

   
    pid_t child_pid1 = fork();

    
    if (child_pid1 < 0) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }
    
    else if (child_pid1 == 0) {
        
        fprintf(file_ptr, "Hello I am child One\n");
        fclose(file_ptr);
        exit(EXIT_SUCCESS);
    }

    
    pid_t child_pid2 = fork();

    
    if (child_pid2 < 0) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }
    
    else if (child_pid2 == 0) {
        
        file_ptr = fopen("data.txt", "a");
        
        fprintf(file_ptr, "Child two has been created\n");
        fclose(file_ptr);
        exit(EXIT_SUCCESS);
    }

    
    wait(NULL);
    wait(NULL);

    
    fclose(file_ptr);

    
    file_ptr = fopen("data.txt", "r");

    
    if (file_ptr == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    
    char buffer[100];
    while (fgets(buffer, sizeof(buffer), file_ptr) != NULL) {
        printf("%s", buffer);
    }

    
    fclose(file_ptr);

    return 0;
}

