#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main() {
    pid_t pid1, pid2;
    FILE *fp;

    
    fp = fopen("data.txt", "w");
    fclose(fp);

   
    pid1 = fork();
    if (pid1 == 0) {
        // Child 1 process
        fp = fopen("data.txt", "a");
        fprintf(fp, "Hello I am child One\n");
        fclose(fp);
        return 0;
    }

   
    pid2 = fork();
    if (pid2 == 0) {
        // Child 2 process
        fp = fopen("data.txt", "a");
        fprintf(fp, "Child two has been created\n");
        fclose(fp);
        return 0;
    }

   
    int status;
    waitpid(pid1, &status, 0);
    waitpid(pid2, &status, 0);

   
    char buffer[100];
    fp = fopen("data.txt", "r");
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        printf("%s", buffer);
    }
    fclose(fp);

    return 0;
}
