#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    FILE *file = fopen("data.txt", "w");
    if (file == NULL) {
        perror("Failed to create file");
        return 1;
    }

    pid_t child1 = fork();
    if (child1 == 0) {
        fprintf(file, "Hello I am child One\n");
        exit(0);
    }

    pid_t child2 = fork();
    if (child2 == 0) {
        fprintf(file, "Child two has been created\n");
        exit(0);
    }

    wait(NULL);

    fclose(file);

    file = fopen("data.txt", "r");
    if (file == NULL) {
        perror("Failed to open file for reading");
        return 1;
    }

    char ch;
    while (fread(&ch, 1, 1, file) == 1) {
        write(1, &ch, 1);
    }

    fclose(file);
    return 0;
}

