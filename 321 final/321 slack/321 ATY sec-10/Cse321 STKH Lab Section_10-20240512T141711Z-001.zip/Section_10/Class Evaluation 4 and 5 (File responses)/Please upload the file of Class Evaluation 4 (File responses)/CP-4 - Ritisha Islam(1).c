#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main() {
   
    FILE *file = fopen("data.txt", "w");
    if (file == NULL) {
        perror("Failed to create file");
        exit(EXITFAILURE);
    }

    pid_t pid1 = fork();
    if (pid1 == -1) {
        perror("Failed to fork first child");
        exit(EXITFAILURE);
    } else if (pid1 == 0) {
       
        fprintf(file, "Hello I am child One\n");
        fclose(file);
        exit(EXITSUCCESS);
    }

    pid_t pid2 = fork();
    if (pid2 == -1) {
        perror("Failed to fork second child");
        exit(EXITFAILURE);
    } else if (pid2 == 0) {
        
        file = fopen("data.txt", "a");
        if (file == NULL) {
            perror("Failed to open file");
            exit(EXITFAILURE);
        }
        fprintf(file, "Child two has been created\n");
        fclose(file);
        exit(EXITSUCCESS);
    }


    fclose(file);
    
    wait(NULL);
    wait(NULL);

    
    file = fopen("data.txt", "r");
    if (file == NULL) {
        perror("Failed to open file for reading");
        exit(EXIT_FAILURE);
    }
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
    }
    fclose(file);

    return 0;
}