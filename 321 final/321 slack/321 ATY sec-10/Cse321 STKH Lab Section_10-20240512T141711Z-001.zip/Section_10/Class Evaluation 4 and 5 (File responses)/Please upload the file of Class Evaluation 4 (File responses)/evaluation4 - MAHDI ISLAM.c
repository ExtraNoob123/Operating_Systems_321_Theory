#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    FILE *fp;
    fp = fopen("data.txt", "w");
    if (fp == NULL) {
        perror("fopen");
        exit(1);
    }

    pid_t child1 = fork();
    if (child1 < 0) {
        perror("fork");
        exit(1);
    } else if (child1 == 0) {
      //1
        fprintf(fp, "Hello I am child One\n");
        fclose(fp);
        exit(0);
    }

    pid_t child2 = fork();
    if (child2 < 0) {
      //2
        perror("fork");
        exit(1);
    } else if (child2 == 0) {
        fprintf(fp, "Child two has been created\n");
        fclose(fp);
        exit(0);
    }

    wait(NULL);
    wait(NULL);

    fp = fopen("data.txt", "r");
    if (fp == NULL) {
        perror("fopen");
        exit(1);
    }

    char buffer[100];
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        printf("%s", buffer);
    }

    fclose(fp);

    return 0;
}
