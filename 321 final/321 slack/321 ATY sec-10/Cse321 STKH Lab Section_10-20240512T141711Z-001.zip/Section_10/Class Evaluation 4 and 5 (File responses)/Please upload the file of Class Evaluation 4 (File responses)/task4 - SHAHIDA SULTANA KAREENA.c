#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    
    FILE *file = fopen("data.txt", "w");
    if (file == NULL) {
        perror("Error creating file");
        return 1;
    }

    
    pid_t child_pid1 = fork();
    if (child_pid1 == 0) {
        
        fprintf(file, "Hello I am child One\n");
        fclose(file);
        exit(0);
    } else if (child_pid1 < 0) {
        perror("Error forking first child");
        return 1;
    }

    
    pid_t child_pid2 = fork();
    if (child_pid2 == 0) {
       
        file = fopen("data.txt", "a");
        if (file == NULL) {
            perror("Error opening file in child 2");
            return 1;
        }
        fprintf(file, "Child two has been created\n");
        fclose(file);
        exit(0);
    } else if (child_pid2 < 0) {
        perror("Error forking second child");
        return 1;
    }

  
    wait(NULL);
    wait(NULL);

   
    file = fopen("data.txt", "r"); 
    if (file == NULL) {
        perror("Error opening file in parent");
        return 1;
    }

    
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
    }

    fclose(file);

    return 0;
}
