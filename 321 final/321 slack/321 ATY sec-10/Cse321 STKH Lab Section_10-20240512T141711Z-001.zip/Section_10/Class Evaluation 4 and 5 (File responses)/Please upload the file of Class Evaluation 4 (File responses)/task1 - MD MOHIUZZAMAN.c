#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    FILE *file = fopen("data.txt", "w");

    pid_t child1 = fork();
    if (child1 == 0) {
        // Child process
        fprintf(file, "Hello I am child One\n");
        fclose(file);
        return 0;
    }

    pid_t child2 = fork();
    if (child2 == 0) {
        fprintf(file, "Child two has been created\n");
        fclose(file);
        return 0;
    }

    // Parent process
    fclose(file);
    file = fopen("data.txt", "r");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }
    
    
    
    waitpid(child1, NULL, 0);
    waitpid(child2, NULL, 0);

    char buff[100];
    while (fgets(buff, sizeof(buff), file)) {
        printf("%s", buff);
    }

    fclose(file);
    return 0;
}
