#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define ARRAY_SIZE 500
#define NUM_THREADS 50


int array[ARRAY_SIZE]; // Array to store values from 1 to 500
int sum = 0; // Shared variable to store the sum
pthread_mutex_t mutex; // Mutex for synchronization


void *threadFunction(void *arg) {
    int *arr = (int *)arg; // Get the array passed as argument

    int localSum = 0;
   
    for (int i = 0; i < ARRAY_SIZE; i++) {
        localSum += arr[i];
    }

    
    pthread_mutex_lock(&mutex);
    sum += localSum; // Update the global sum
    pthread_mutex_unlock(&mutex); // Release the mutex

    pthread_exit(NULL);
}

int main() {
    // Populate the array with values from 1 to 500
    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i + 1;
    }

    
    if (pthread_mutex_init(&mutex, NULL) != 0) {
        perror("Mutex initialization failed");
        exit(EXIT_FAILURE);
    }

    pthread_t threads[NUM_THREADS];


    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_create(&threads[i], NULL, threadFunction, (void *)array) != 0) {
            perror("Thread creation failed");
            exit(EXIT_FAILURE);
        }
    }

   
    for (int i = 0; i < NUM_THREADS; i++) {
        int randomIndex = rand() % NUM_THREADS; // Generate random index
        if (pthread_join(threads[randomIndex], NULL) != 0) {
            perror("Thread join failed");
            exit(EXIT_FAILURE);
        }
    }


    printf("Sum: %d\n", sum);
    pthread_mutex_destroy(&mutex);

    return 0;
}
