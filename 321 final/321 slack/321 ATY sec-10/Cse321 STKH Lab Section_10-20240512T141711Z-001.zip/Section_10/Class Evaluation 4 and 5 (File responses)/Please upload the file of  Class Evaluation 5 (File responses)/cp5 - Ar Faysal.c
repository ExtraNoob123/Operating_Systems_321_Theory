#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define ARRAY_LENGTH 1000
#define NUM_THREADS 100
int array[ARRAY_LENGTH];
int sum = 0;
pthread_mutex_t mutex;
void* thread_function(void* arg) {
    int* array_ptr=(int*)arg;
    int local_sum=0;
    for (int i=0;i < ARRAY_LENGTH;i++) {
        local_sum+=array_ptr[i];
    }
    pthread_mutex_lock(&mutex);
    sum+=local_sum;
    pthread_mutex_unlock(&mutex);
    pthread_exit(NULL);
}
int main() {
    pthread_t threads[NUM_THREADS];
    pthread_mutex_init(&mutex, NULL);
    for (int i=0; i < ARRAY_LENGTH; i++) {
        array[i]=i+1;
    }
    for (int i=0;i < NUM_THREADS;i++) {
        if (pthread_create(&threads[i], NULL, thread_function, (void*)array) != 0) {
            perror("Thread creation failed");
            return 1;
        }
    }
    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_join(threads[rand() % NUM_THREADS], NULL) != 0) {
            perror("Thread join failed");
            return 1;
        }
    }
    printf("Sum: %d\n", sum);
    pthread_mutex_destroy(&mutex);
    return 0;
}

