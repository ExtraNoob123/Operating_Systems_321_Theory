#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define ARRAY_SIZE 500
#define NUM_THREADS 50

int array[ARRAY_SIZE];
int sum = 0;
pthread_mutex_t mutex;

void *thread_function(void *arg) {
    int *arr = (int *)arg;
    int local_sum = 0;

    for (int i = 0; i < ARRAY_SIZE; i++) {
        local_sum += arr[i];
    }

    pthread_mutex_lock(&mutex);
    sum += local_sum;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    pthread_mutex_init(&mutex, NULL);

    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i + 1;
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, thread_function, (void *)array);
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("Sum: %d\n", sum);

    pthread_mutex_destroy(&mutex);
    return 0;
}
