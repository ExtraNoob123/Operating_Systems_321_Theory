#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

#define ARRAY_SIZE 500
#define NUM_THREADS 50

int array[ARRAY_SIZE];
int sum = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void *thread_function(void *arg) {
    int *arr = (int *)arg;
    int local_sum = 0;

    for (int i = 0; i < ARRAY_SIZE; i++) {
        local_sum += arr[i];
    }

    pthread_mutex_lock(&mutex);
    sum += local_sum;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];

    
    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i + 1;
    }

    
    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_create(&threads[i], NULL, thread_function, (void *)array) != 0) {
            perror("pthread_create");
            exit(EXIT_FAILURE);
        }
    }

    
    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            perror("pthread_join");
            exit(EXIT_FAILURE);
        }
    }

    
    printf("Sum: %d\n", sum);

    return 0;
}

