#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>


int array[500];
int sum = 0;
pthread_mutex_t mutex;
void *threadFunction(void *arg);

int main() {
    pthread_t threads[50];
    pthread_mutex_init(&mutex, NULL);
    for (int i = 0; i < 500; i++) {
        array[i] = i + 1;
    }
    for (int i = 0; i < 50; i++) {
        pthread_create(&threads[i], NULL, threadFunction, NULL);
    }
    for (int i = 0; i < 50; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);
    printf("Sum: %d\n", sum);
    return 0;
}

void *threadFunction(void *arg) {
    int localSum = 0;
    for (int i = 0; i < 500; i++) {
        localSum += array[i];
    }
    pthread_mutex_lock(&mutex);
    sum += localSum;
    pthread_mutex_unlock(&mutex);
    return NULL;
}
