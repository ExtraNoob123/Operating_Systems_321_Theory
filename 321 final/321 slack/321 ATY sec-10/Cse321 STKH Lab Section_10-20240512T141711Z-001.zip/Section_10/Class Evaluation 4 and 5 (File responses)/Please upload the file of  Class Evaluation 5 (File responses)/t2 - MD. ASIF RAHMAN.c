#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define ARRAY_SIZE 500
#define NUM_THREADS 50

int array[ARRAY_SIZE];
int sum = 0;
sem_t semaphore;

void *thread_function(void *arg) {
    int *local_array = (int *)arg;
    int local_sum = 0;

    for (int i = 0; i < ARRAY_SIZE; i++) {
        local_sum += local_array[i];
    }

    if (sem_wait(&semaphore) != 0) {
        perror("sem_wait");
        pthread_exit(NULL);
    }
    sum += local_sum;
    
    if (sem_post(&semaphore) != 0) {
        perror("sem_post");
        pthread_exit(NULL);
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    int res;
  
    if (sem_init(&semaphore, 0, 1) != 0) {
        perror("sem_init");
        exit(EXIT_FAILURE);
    }
  
    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i + 1;
    }
  
    for (int i = 0; i < NUM_THREADS; i++) {
        int *thread_array = (int *)malloc(ARRAY_SIZE * sizeof(int));
        if (thread_array == NULL) {
            perror("Memory allocation failed");
            exit(EXIT_FAILURE);
        }
        
        for (int j = 0; j < ARRAY_SIZE; j++) {
            thread_array[j] = array[j];
        }
        res = pthread_create(&threads[i], NULL, thread_function, (void *)thread_array);
        if (res != 0) {
            fprintf(stderr, "pthread_create failed: %d\n", res);
            exit(EXIT_FAILURE);
        }
    }
 
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
  
    if (sem_destroy(&semaphore) != 0) {
        perror("sem_destroy");
        exit(EXIT_FAILURE);
    }

    printf("Sum: %d\n", sum);

    return 0;
}

