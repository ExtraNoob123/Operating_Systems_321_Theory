#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define ARRAY_LENGTH 500
#define NUM_THREADS 50

int array[ARRAY_LENGTH];
int sum = 0;
pthread_mutex_t mutex;

void *thread_function(void *arg) {
    int *arr = (int *)arg;
    int local_sum = 0;

   
    for (int i = 0; i < ARRAY_LENGTH; i++) {
        local_sum += arr[i];
    }

    
    pthread_mutex_lock(&mutex);
    sum += local_sum;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main() {
    
    for (int i = 0; i < ARRAY_LENGTH; i++) {
        array[i] = i + 1;
    }

  
    pthread_mutex_init(&mutex, NULL);

   
    pthread_t threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, thread_function, (void *)array);
    }

    
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[rand() % NUM_THREADS], NULL);
    }

 
    pthread_mutex_destroy(&mutex);

    
    printf("Sum: %d\n", sum);

    return 0;
}
