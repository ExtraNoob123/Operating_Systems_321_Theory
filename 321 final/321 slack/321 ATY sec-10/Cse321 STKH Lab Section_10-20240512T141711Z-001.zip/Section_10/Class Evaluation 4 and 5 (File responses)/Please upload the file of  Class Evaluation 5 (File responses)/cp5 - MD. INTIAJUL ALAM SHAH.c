#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 50
#define ARRAY_SIZE 500

int array[ARRAY_SIZE];
int sum = 0;
pthread_mutex_t mutex;

void *thread_function(void *arg) {
    int *arr = (int *)arg;
    int local_sum = 0;

  
    for (int i = 0; i < ARRAY_SIZE; i++) {
        local_sum += arr[i];
    }

   
    pthread_mutex_lock(&mutex);
    sum += local_sum;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    int i, rc;

   
    for (i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i + 1;
    }

    pthread_mutex_init(&mutex, NULL);

    
   
