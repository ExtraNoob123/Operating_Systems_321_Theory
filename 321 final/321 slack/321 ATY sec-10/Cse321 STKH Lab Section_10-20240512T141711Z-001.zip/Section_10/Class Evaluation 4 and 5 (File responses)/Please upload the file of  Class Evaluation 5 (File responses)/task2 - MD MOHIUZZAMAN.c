#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define arr_len 500
#define num_threads 50

sem_t semaphore;
int sum = 0;
int array[arr_len];

void *thread_func(void *arg) {
    for (int i = 0; i < arr_len; i++) {
        sem_wait(&semaphore);
        sum += array[i];
        sem_post(&semaphore);
    }
    return NULL;
}

int main() {
    pthread_t threads[num_threads];
    sem_init(&semaphore, 0, 1);
    
    for (int i = 0; i < arr_len; i++) {
        array[i] = i + 1;
    }

    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, thread_func, NULL);
    }

    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("The Total Sum: %d\n", sum);

    sem_destroy(&semaphore);

    return 0;
}
