#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int arr[500];
int sum = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void* func(void* arg) {
    int* ar = (int*)arg;
    int s = 0;

    
    for (int i = 0; i < 500; ++i) {
        s += ar[i];
    }
    
    pthread_mutex_lock(&mutex);
    sum += s;
    pthread_mutex_unlock(&mutex);

}

int main() {

    for (int i = 0; i < 500; ++i) {
        arr[i] = i + 1;
    }


    pthread_t threads[50];
    for (int i = 0; i < 50; ++i) {
        pthread_create(&threads[i], NULL, func, (void*)arr);
    }


    pthread_mutex_destroy(&mutex);
    printf("Sum: %d\n", sum);

    return 0;
}