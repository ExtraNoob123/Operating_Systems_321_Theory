#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define l 500
#define thr_no 50

int sum = 0;
int array[l];
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void *Sum(void *arg) {
    int *arr = (int *)arg;
    int sum1 = 0;
    for (int i = 0; i < l; i++) {
        sum1 += arr[i];
    }
    pthread_mutex_lock(&mutex);
    sum += sum1;
    pthread_mutex_unlock(&mutex);
    pthread_exit(NULL);
}
int main() {
    pthread_t threads[thr_no];
    for (int i = 0;i<l;i++){
        array[i]= i+1;
    }
   
   for (int i = 0; i < thr_no; i++) {
        if (pthread_create(&threads[i], NULL, Sum, (void *)array) != 0) {
            fprintf(stderr, "Error creating thread\n");
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < thr_no; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            fprintf(stderr, "Error joining thread\n");
            exit(EXIT_FAILURE);
        }
    }
    printf("sum: %d\n", sum);
    return 0;
}
