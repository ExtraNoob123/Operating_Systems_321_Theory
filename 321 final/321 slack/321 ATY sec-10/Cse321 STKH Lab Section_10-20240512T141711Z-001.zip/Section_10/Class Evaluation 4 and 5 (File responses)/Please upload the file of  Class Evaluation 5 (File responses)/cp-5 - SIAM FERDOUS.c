#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h> 
#include <pthread.h>

#define arr 500
#define t_count 50

int array[arr];
int total= 0;
pthread_mutex_t mutex;

void *t_func(void *arg) {
    int *array = (int *)arg;
    int sum = 0;

    for (int i = 0; i < arr; i++)
        sum += array[i];

    pthread_mutex_lock(&mutex);
    total += sum;
    pthread_mutex_unlock(&mutex);

    return 0;
}

int main() {
    pthread_t threads[t_count];

    for (int i = 0; i < arr; i++)
        array[i] = i + 1;

    pthread_mutex_init(&mutex, NULL);

    for (int i = 0; i < t_count; i++)
        pthread_create(&threads[i], NULL, t_func, array);

    for (int i = 0; i < t_count; i++)
        pthread_join(threads[i], NULL);

    printf("Sum:%d\n", total);

    pthread_mutex_destroy(&mutex);

    return 0;
}
