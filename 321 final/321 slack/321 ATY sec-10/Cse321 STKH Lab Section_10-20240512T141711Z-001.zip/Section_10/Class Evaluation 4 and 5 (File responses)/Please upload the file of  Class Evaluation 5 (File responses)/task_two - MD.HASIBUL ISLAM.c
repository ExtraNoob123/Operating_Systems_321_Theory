#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define ARRAY_SIZE 500
#define NUM_THREADS 50

int data_array[ARRAY_SIZE];
int total_sum = 0;
pthread_mutex_t mutex;

void *thread_function(void *arg) {
    int *data_ptr = (int *)arg;
    int thread_sum = 0;

    int i = 0;
    while (i < ARRAY_SIZE) {
        thread_sum += data_ptr[i];
        i++;
    }

    pthread_mutex_lock(&mutex);
    total_sum += thread_sum;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    pthread_mutex_init(&mutex, NULL);

    int i = 0;
    while (i < ARRAY_SIZE) {
        data_array[i] = i + 1;
        i++;
    }

    i = 0;
    while (i < NUM_THREADS) {
        pthread_create(&threads[i], NULL, thread_function, (void *)data_array);
        i++;
    }

    i = 0;
    while (i < NUM_THREADS) {
        pthread_join(threads[i], NULL);
        i++;
    }

    printf("Total Sum: %d\n", total_sum);

    pthread_mutex_destroy(&mutex);

    return 0;
}

