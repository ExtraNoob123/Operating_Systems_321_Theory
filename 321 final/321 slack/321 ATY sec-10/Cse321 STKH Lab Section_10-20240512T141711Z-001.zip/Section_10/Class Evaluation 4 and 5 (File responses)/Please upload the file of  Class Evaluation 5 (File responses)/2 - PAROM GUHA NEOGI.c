#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define ARRAY_SIZE 500
#define NUM_THREADS 50

int array[ARRAY_SIZE];
int sum = 0;
pthread_mutex_t mutex;

void *threadFunction(void *arg) {
    int *arr = (int *)arg;
    int localSum = 0;

    for (int i = 0; i < ARRAY_SIZE; i++) {
        localSum += arr[i];
    }

    pthread_mutex_lock(&mutex);
    sum += localSum;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    pthread_mutex_init(&mutex, NULL);

    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i + 1;
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_create(&threads[i], NULL, threadFunction, (void *)array) != 0) {
            fprintf(stderr, "Error creating thread %d\n", i);
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);

    printf("Sum: %d\n", sum);

    return 0;
}
