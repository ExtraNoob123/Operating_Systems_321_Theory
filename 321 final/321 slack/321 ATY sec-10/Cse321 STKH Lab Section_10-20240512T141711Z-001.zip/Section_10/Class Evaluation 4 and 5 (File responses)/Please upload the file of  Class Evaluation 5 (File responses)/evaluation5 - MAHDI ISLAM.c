#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_THREADS 50
#define ARRAY_SIZE 500

int arr[ARRAY_SIZE];
int sum = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void* add_elements(void* arg) {
    int *arr = (int*)arg;

    for (int i = 0; i < ARRAY_SIZE; i++) {
        pthread_mutex_lock(&mutex); 
        sum += arr[i];
        pthread_mutex_unlock(&mutex); 
    }
    return NULL;
}

int main() {
    for (int i = 0; i < ARRAY_SIZE; i++) {
        arr[i] = i + 1;
    }

    pthread_t threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_create(&threads[i], NULL, add_elements, arr) != 0) {
            perror("pthread_create");
            exit(1);
        }
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_detach(threads[i]) != 0) {
            perror("pthread_detach");
        }
    }


    printf("Sum: %d\n", sum);

    pthread_mutex_destroy(&mutex);
    return 0;
}
