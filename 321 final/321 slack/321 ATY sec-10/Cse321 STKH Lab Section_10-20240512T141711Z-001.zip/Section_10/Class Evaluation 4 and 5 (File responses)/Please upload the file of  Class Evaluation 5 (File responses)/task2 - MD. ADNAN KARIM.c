#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 50
#define ARRAY_SIZE 500

int arr[ARRAY_SIZE];
int sum = 0;
pthread_mutex_t mutex;

void* thread_func(void* arg) {
    int sum1 = 0;
    for (int i = 0; i < ARRAY_SIZE; i++) 
    {
        sum1 += arr[i];
    }

    pthread_mutex_lock(&mutex);
    sum += sum1;
    pthread_mutex_unlock(&mutex);
    pthread_exit(NULL);
}

int main() {
    for (int i = 0; i < ARRAY_SIZE; i++) {
        arr[i] = i + 1;
    }


    pthread_mutex_init(&mutex, NULL);


    pthread_t threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++) 
    {
    
        pthread_create(&threads[i], NULL, thread_func, NULL);
    }


    for (int i = 0; i < NUM_THREADS; i++) 
    {
        pthread_join(threads[i], NULL);
    }

    printf("Sum: %d\n", sum);
    pthread_mutex_destroy(&mutex);
    return 0;
}



