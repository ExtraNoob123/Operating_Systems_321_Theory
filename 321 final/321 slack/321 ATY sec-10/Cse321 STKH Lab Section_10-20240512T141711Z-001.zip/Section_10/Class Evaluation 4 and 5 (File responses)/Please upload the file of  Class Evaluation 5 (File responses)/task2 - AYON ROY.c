#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define ARRAY_SIZE 500
#define NUM_THREADS 50

int *array;
int sum = 0;
pthread_mutex_t mutex;

void *thread_func(void *arg) {
    int *arr = (int *)arg;
    int thread_sum = 0;

    for (int i = 0; i < ARRAY_SIZE; i++) {
        thread_sum += arr[i];
    }
    pthread_mutex_lock(&mutex);
    sum += thread_sum;
    pthread_mutex_unlock(&mutex);
    
    pthread_exit(NULL);
}

int main() {
    array = (int *)malloc(ARRAY_SIZE * sizeof(int));
    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i + 1;
    }
    pthread_mutex_init(&mutex, NULL);

    pthread_t threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, thread_func, (void *)array);
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
    printf("Output should be:\nSum: %d\n", sum);
    free(array);
    pthread_mutex_destroy(&mutex);

    return 0;
}

