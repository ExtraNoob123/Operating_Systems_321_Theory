#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>

int array[500];
long long sum = 0;
pthread_mutex_t mutex_lock;

void *addition(void *arg) {
    int *arr = (int *)arg;
    long long thread_sum = 0;
    for (int i = 0; i < 500; i++) {
        thread_sum += arr[i];
    }
    pthread_mutex_lock(&mutex_lock);
    sum += thread_sum;
    pthread_mutex_unlock(&mutex_lock);
    pthread_exit(NULL);
}
int main() {
    for (int i = 0; i < 500; i++) {
        array[i] = i + 1;
    }
    pthread_mutex_init(&mutex_lock, NULL);
    pthread_t threads[50];
    for (int i = 0; i < 50; i++) {
        if (pthread_create(&threads[i], NULL, addition, (void *)array) != 0) {
            perror("Failed to create thread");
            exit(EXIT_FAILURE);
        }
    }
    for (int i = 0; i < 50; i++) {
        pthread_join(threads[i], NULL);
    }
    pthread_mutex_destroy(&mutex_lock);
    printf("Sum: %lld\n", sum);
    return 0;
}

