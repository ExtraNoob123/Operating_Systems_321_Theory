#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#define ARRAY_SIZE 500
#define NUM_THREADS 50

int array[ARRAY_SIZE];
int sum = 0;
pthread_mutex_t mutex;

int main(){
    pthread_t threads[NUM_THREADS];

    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = i + 1;
    }
    pthread_mutex_init(&mutex, NULL);

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, thread_function, (void *)array);
    }


    pthread_mutex_destroy(&mutex);

    printf("Sum: %d\n", sum);
}
void *t_func(int *id){
	printf("Entered in Thread %d...\n",*id);
	for (int i = 0; i < ARRAY_SIZE; i++) {
        sum += arr[i];
    }
	    pthread_mutex_lock(&mutex);
	    sum += arr[i];
		pthread_mutex_unlock(&mutex);
